from app import app, db
from models import *
from views import *
from errors import *

#equivalent to what is imported in __init__.py lower part + microblog.py

"""EXECUTE FIRST"""
if __name__ == '__main__':
    app.run()

#to use flask shell command when using the python interpreter
#this way, all these modules are already imported
@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'Blogpost': Blogpost, 'Editors': Editors, 'Logins': Logins}
